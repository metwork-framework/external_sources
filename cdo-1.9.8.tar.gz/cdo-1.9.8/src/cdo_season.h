enum
{
  START_DEC,
  START_JAN
};

int getSeasonStart(void);

void getSeasonName(const char *seas_name[]);

int monthToSeason(int month);
