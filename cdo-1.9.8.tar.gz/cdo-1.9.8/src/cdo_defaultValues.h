#ifndef CDO_DEFAULTVALUES_H
#define CDO_DEFAULTVALUES_H

#include "cdi.h"

namespace CdoDefault
{
extern int FileType;
extern int DataType;
extern int Byteorder;
extern int TableID;
extern int InstID;
extern int TaxisType;
}  // namespace CdoDefault

#endif
