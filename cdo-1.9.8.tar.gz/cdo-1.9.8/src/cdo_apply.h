#include <vector>

/*
 * this feature of cdo allows the use of the -apply keyword.
 * When used all files that are inside the ][ brackets of apply are prepended with given operator.
 */

/*
 * checks for:
 *  missing bracket at pos after -apply -> error
 *  checks for new bracket -> error
 *  checks for no closing bracket -> error
 *  checks for apply not beeing at the first position in the argument string -> error
 *  checks for missing argument for apply
 *  checks for operators that are used within the apply brackets -> error
 */

/*
 * supports:
 * operators with number of inputs = 1 (no others)
 * operators with arguments: written as -apply,OPERNAME,arguments
 */

std::vector<std::string> expandApply(std::vector<std::string> p_argv);
