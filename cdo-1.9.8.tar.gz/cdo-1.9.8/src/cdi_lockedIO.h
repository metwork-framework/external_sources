#ifndef CDI_LOCKEDIO_H
#define CDI_LOCKEDIO_H

#include <cstddef>

int streamOpenReadLocked(const char *filename);
void streamCloseLocked(int p_fileID);
void streamInqRecLocked(int p_fileID, int *p_varID, int *p_levelID);
void streamDefRecLocked(int p_fileID, int p_varID, int levelID);
void streamReadrecordFloatLocked(int p_fileID, float *p_data, size_t *p_nmiss);
void streamReadrecordDoubleLocked(int p_fileID, double *p_data, size_t *p_nmiss);
void streamDefVlistLocked(int p_fileID, int p_vlistID);
int streamInqVlistLocked(int p_fileID);
void streamWriteRecordDoubleLocked(int p_fileID, double *p_data, size_t p_nmiss);
void streamWriteRecordFloatLocked(int p_fileID, float *p_data, size_t p_nmiss);
int streamInqTimeStepLocked(int p_fileID, int p_tsID);
int streamDefTimeStepLocked(int p_fileID, int p_tsID);
int streamCopyRecordLocked(int p_fileID, int p_targetFileID);
void vlistCopyFlagLocked(int p_vlistID2, int p_vlistID1);
void openLock(void);
void openUnlock(void);
void cdoVlistCopyFlag(int vlistID2, int vlistID1);
#endif
