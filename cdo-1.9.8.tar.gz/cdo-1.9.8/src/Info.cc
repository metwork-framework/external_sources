/*
  This file is part of CDO. CDO is a collection of Operators to
  manipulate and analyse Climate model Data.

  Copyright (C) 2003-2019 Uwe Schulzweida, <uwe.schulzweida AT mpimet.mpg.de>
  See COPYING file for copying and redistribution conditions.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
*/

/*
   This module contains the following operators:

      Info       info            Dataset information
      Info       map             Dataset information and simple map
*/

#include <cfloat>

#include <cdi.h>

#include "cdo_options.h"
#include "process_int.h"
#include "mpmo_color.h"
#include "array.h"
#include "datetime.h"
#include "printinfo.h"
#include "cdo_zaxis.h"


static void
printGridIndex(int nlon, int nlat, int ilon, int i)
{
  const int index = nlat < 10 ? 2 : nlat < 100 ? 3 : nlat < i ? 4 : 5;

  std::stringstream s;
  s << std::string(index, ' ');
  for (ilon = 0; ilon < nlon; ilon++) s << ((ilon + 1) / i) % 10;

  printf("%s", s.str().c_str());
  putchar('\n');
  fflush(stdout);
}

static void
printMap(const int nlon, const int nlat, const double *array, const double missval, const double min, const double max)
{
  // source code from PINGO
  int ilon, ilat, i;
  double x, a, b;
  double level[10];
  int min_n, max_n;
  int bmin = 1, bmax = 1;
  unsigned char c;

  double step = (max - min) / 10;

  if (IS_NOT_EQUAL(step, 0))
    {
      a = std::pow(10, std::floor(std::log(step) / M_LN10));
      b = step / a;

      if (b > 5)
        b = 0.5 * std::ceil(b / 0.5);
      else if (b > 2)
        b = 0.2 * std::ceil(b / 0.2);
      else if (b > 1)
        b = 0.1 * std::ceil(b / 0.1);
      else
        b = 1;

      step = b * a;

      if (min < 0 && max > 0)
        {
          min_n = (int) std::floor(10 * (-min) / (max - min) - 0.5);
          max_n = (int) std::ceil(10 * (-min) / (max - min) - 0.5);
          level[min_n] = 0;
          for (i = min_n - 1; i >= 0; i--) level[i] = level[i + 1] - step;
          for (i = max_n; i < 9; i++) level[i] = level[i - 1] + step;
        }
      else
        {
          level[0] = step * std::ceil(min / step + 0.5);
          for (i = 1; i < 9; i++) level[i] = level[i - 1] + step;
        }
    }
  else
    for (i = 0; i < 9; i++) level[i] = min;

  fputc('\n', stdout);
  fflush(stdout);

  if (nlon >= 1000)
    {
      printf("%.*s", nlat < 10 ? 2 : nlat < 100 ? 3 : nlat < 1000 ? 4 : 5, "     ");
      for (ilon = 0; ilon < nlon; ilon++) printf("%d", ((ilon + 1) / 1000) % 10);
      putchar('\n');
      fflush(stdout);
    }

  if (nlon >= 100)
    {
      printf("%.*s", nlat < 10 ? 2 : nlat < 100 ? 3 : nlat < 1000 ? 4 : 5, "     ");
      for (ilon = 0; ilon < nlon; ilon++) printf("%d", ((ilon + 1) / 100) % 10);
      putchar('\n');
      fflush(stdout);
    }

  if (nlon >= 10)
    {
      printf("%.*s", nlat < 10 ? 2 : nlat < 100 ? 3 : nlat < 1000 ? 4 : 5, "     ");
      for (ilon = 0; ilon < nlon; ilon++) printf("%d", ((ilon + 1) / 10) % 10);
      putchar('\n');
      fflush(stdout);
    }

  printf("%.*s", nlat < 10 ? 2 : nlat < 100 ? 3 : nlat < 1000 ? 4 : 5, "     ");

  for (ilon = 0; ilon < nlon; ilon++) printf("%d", (ilon + 1) % 10);
  putchar('\n');
  fflush(stdout);
  putchar('\n');
  fflush(stdout);

  for (ilat = 0; ilat < nlat; ilat++)
    {
      printf("%0*d ", nlat < 10 ? 1 : nlat < 100 ? 2 : nlat < 1000 ? 3 : 4, ilat + 1);
      for (ilon = 0; ilon < nlon; ilon++)
        {
          x = array[ilat * nlon + ilon];
          if (DBL_IS_EQUAL(x, missval))
            c = '.';
          else if (DBL_IS_EQUAL(x, min) && !DBL_IS_EQUAL(min, max))
            c = 'm';
          else if (DBL_IS_EQUAL(x, max) && !DBL_IS_EQUAL(min, max))
            c = 'M';
          else if (DBL_IS_EQUAL(x, 0.))
            c = '*';
          else if (x < 0)
            {
              c = '9';
              for (i = 0; i < 9; i++)
                if (level[i] > x)
                  {
                    c = i + '0';
                    break;
                  }
            }
          else
            {
              c = '0';
              for (i = 8; i >= 0; i--)
                if (level[i] < x)
                  {
                    c = i + 1 + '0';
                    break;
                  }
            }

          TextMode mode(MODELESS);
          TextColor color(BLACK);
          switch (c)
            {
            /* clang-format off */
            case '0': mode = BRIGHT   ; color = BLUE    ; break ;
            case '1': mode = MODELESS ; color = BLUE    ; break ;
            case '2': mode = BRIGHT   ; color = CYAN    ; break ;
            case '3': mode = MODELESS ; color = CYAN    ; break ;
            case '4': mode = MODELESS ; color = GREEN   ; break ;
            case '5': mode = MODELESS ; color = YELLOW  ; break ;
            case '6': mode = MODELESS ; color = RED     ; break ;
            case '7': mode = BRIGHT   ; color = RED     ; break ;
            case '8': mode = MODELESS ; color = MAGENTA ; break ;
            case '9': mode = BRIGHT   ; color = MAGENTA ; break ;
            /* clang-format on */
            case 'm':
              bmax == 1 ? mode = BLINK : mode = MODELESS, color = BLACK;
              if (bmax) bmax = 0;
              break;
            case 'M':
              bmin == 1 ? mode = BLINK : mode = MODELESS, color = BLACK;
              if (bmin) bmin = 0;
              break;
            }

          set_text_color(stdout, mode, color);
          putchar(c);
          reset_text_color(stdout);
        }
      printf(" %0*d\n", nlat < 10 ? 1 : nlat < 100 ? 2 : nlat < 1000 ? 3 : 4, ilat + 1);
      fflush(stdout);
    }
  putchar('\n');
  fflush(stdout);

  for (int i = 1; i <= 4; i++)
    {
      int current = 10000 / std::pow(10, i);
      if (nlon >= current)
        {
          printGridIndex(nlon, nlat, ilon, current);
        }
    }
  fflush(stdout);
  putchar('\n');
  fflush(stdout);

  for (i = 0; i < 10; i++)
    {
      printf("%d=%c%+9.3e,%+9.3e%c%s", i, '[', i == 0 ? min : level[i - 1], i == 9 ? max : level[i],
             i == 9 || level[i] <= 0 ? ']' : ']', i != 2 && i != 5 && i != 8 ? "  " : "");

      if (i == 2 || i == 5 || i == 8)
        {
          fputc('\n', stdout);
          fflush(stdout);
        }
    }

  printf("*=0  .=miss  m=min=%+9.3e  M=max=%+9.3e\n", min, max);
  fflush(stdout);
  putchar('\n');
  fflush(stdout);
}

struct Infostat
{
  double min, max, sum, sumi;
  size_t nvals, nmiss, nlevs;
};

static void
infostatInit(Infostat &infostat)
{
  infostat.nvals = 0;
  infostat.nmiss = 0;
  infostat.nlevs = 0;
  infostat.min = DBL_MAX;
  infostat.max = -DBL_MAX;
  infostat.sum = 0;
  infostat.sumi = 0;
}

void *
Info(void *process)
{
  enum
  {
    E_NAME,
    E_CODE,
    E_PARAM
  };
  int fpeRaised = 0;
  int varID, levelID;
  int nrecs;
  size_t nmiss;
  size_t imiss = 0;
  char varname[CDI_MAX_NAME];
  char paramstr[32];

  cdoInitialize(process);

  // clang-format off
  const auto INFO   = cdoOperatorAdd("info",   E_PARAM,  0, nullptr);
  const auto INFOP  = cdoOperatorAdd("infop",  E_PARAM,  0, nullptr);
  const auto INFON  = cdoOperatorAdd("infon",  E_NAME,   0, nullptr);
  const auto INFOC  = cdoOperatorAdd("infoc",  E_CODE,   0, nullptr);
  const auto VINFON = cdoOperatorAdd("vinfon", E_NAME,   0, nullptr);
  const auto XINFON = cdoOperatorAdd("xinfon", E_NAME,   0, nullptr);
  const auto MAP    = cdoOperatorAdd("map",    E_PARAM,  0, nullptr);
  // clang-format on

  (void)(INFO); //CDO_UNUSED
  (void)(INFOP); //CDO_UNUSED
  (void)(INFON); //CDO_UNUSED
  (void)(INFOC); //CDO_UNUSED

  const auto operatorID = cdoOperatorID();
  const auto operfunc = cdoOperatorF1(operatorID);

  const bool lvinfo = (operatorID == VINFON || operatorID == XINFON);

  DateTimeList dtlist;

  std::string e = "";
  if (operfunc == E_NAME)
    e = "Parameter name";
  else if (operfunc == E_CODE)
    e = "Code number";
  else
    e = "Parameter ID";

  std::string v = (Options::cdoVerbose) ? " : Extra" : "";
  int indg = 0;

  for (int indf = 0; indf < cdoStreamCnt(); indf++)
    {
      const auto streamID = cdoOpenRead(indf);
      const auto vlistID = cdoStreamInqVlist(streamID);
      const auto taxisID = vlistInqTaxis(vlistID);

      const auto nvars = vlistNvars(vlistID);
      if (nvars == 0) continue;

      std::vector<Infostat> infostat(nvars);

      auto gridsizemax = vlistGridsizeMax(vlistID);
      if (vlistNumber(vlistID) != CDI_REAL) gridsizemax *= 2;

      std::vector<float> arrayf;
      Varray<double> array;
      if (Options::CDO_Memtype == MEMTYPE_FLOAT)
        arrayf.resize(gridsizemax);
      else
        array.resize(gridsizemax);

      indg = 0;
      int tsID = 0;
      while ((nrecs = cdoStreamInqTimestep(streamID, tsID)))
        {
          dtlist.taxisInqTimestep(taxisID, 0);
          const auto vdate = dtlist.getVdate(0);
          const auto vtime = dtlist.getVtime(0);
          const auto vdateString = dateToString(vdate);
          const auto vtimeString = timeToString(vtime);

          for (varID = 0; varID < nvars; ++varID) infostatInit(infostat[varID]);

          for (int recID = 0; recID < nrecs; ++recID)
            {
              if ((tsID == 0 && recID == 0) || operatorID == MAP)
                {
                  set_text_color(stdout, BRIGHT);
                  MpMO::Print("%6d :       Date     Time   %s Gridsize    Miss :     Minimum        Mean     Maximum : %s%s",
                              -(indf + 1), lvinfo ? "Nlevs" : "Level", e, v);
                  reset_text_color(stdout);
                }

              cdoInqRecord(streamID, &varID, &levelID);
              if (Options::CDO_Memtype == MEMTYPE_FLOAT)
                cdoReadRecordF(streamID, arrayf.data(), &nmiss);
              else
                cdoReadRecord(streamID, array.data(), &nmiss);

              indg = lvinfo ? varID + 1 : indg + 1;

              const auto param = vlistInqVarParam(vlistID, varID);
              const auto code = vlistInqVarCode(vlistID, varID);
              const auto gridID = vlistInqVarGrid(vlistID, varID);
              const auto zaxisID = vlistInqVarZaxis(vlistID, varID);
              const auto number = vlistInqVarNumber(vlistID, varID);
              const auto gridsize = gridInqSize(gridID);
              const size_t nlevs = zaxisInqSize(zaxisID);
              const auto level = cdoZaxisInqLevel(zaxisID, levelID);
              const auto missval = vlistInqVarMissval(vlistID, varID);

              bool loutput = !lvinfo;

              if (loutput) infostatInit(infostat[varID]);

              auto &infostatr = infostat[varID];
              infostatr.nlevs += 1;
              infostatr.nmiss += nmiss;

              if (nlevs == infostatr.nlevs) loutput = true;

              if (loutput)
                {
                  cdiParamToString(param, paramstr, sizeof(paramstr));

                  if (operfunc == E_NAME) vlistInqVarName(vlistID, varID, varname);

                  fprintf(stdout, "%6d ", indg);
                  fprintf(stdout, ":");

                  set_text_color(stdout, MAGENTA);
                  fprintf(stdout, "%s %s ", vdateString.c_str(), vtimeString.c_str());
                  reset_text_color(stdout);

                  set_text_color(stdout, GREEN);
                  if (lvinfo)
                    fprintf(stdout, "%7zu ", nlevs);
                  else
                    fprintf(stdout, "%7g ", level);

                  fprintf(stdout, "%8zu %7zu ", gridsize, infostatr.nmiss);
                  reset_text_color(stdout);

                  fprintf(stdout, ":");

                  set_text_color(stdout, BLUE);
                }

              if (number == CDI_REAL)
                {
                  fpeRaised = 0;

                  if (infostatr.nmiss)
                    {
                      size_t nvals;
                      if (Options::CDO_Memtype == MEMTYPE_FLOAT)
                        nvals = varrayMinMaxSumMV_f(gridsize, arrayf, missval, infostatr.min, infostatr.max, infostatr.sum);
                      else
                        nvals = varrayMinMaxSumMV(gridsize, array, missval, infostatr.min, infostatr.max, infostatr.sum);
                      imiss = gridsize - nvals;
                      infostatr.nvals += nvals;
                    }
                  else if (gridsize == 1)
                    {
                      const double val = (Options::CDO_Memtype == MEMTYPE_FLOAT) ? arrayf[0] : array[0];
                      if (infostatr.nvals == 0)
                        infostatr.sum = val;
                      else
                        infostatr.sum += val;
                      infostatr.nvals += 1;
                    }
                  else
                    {
                      if (Options::CDO_Memtype == MEMTYPE_FLOAT)
                        varrayMinMaxSum_f(gridsize, arrayf, infostatr.min, infostatr.max, infostatr.sum);
                      else
                        varrayMinMaxSum(gridsize, array, infostatr.min, infostatr.max, infostatr.sum);
                      infostatr.nvals += gridsize;
                    }

                  if (loutput)
                    {
                      if (infostatr.nvals)
                        {
                          if (infostatr.nvals == 1)
                            {
                              fprintf(stdout, "            %#12.5g            ", infostatr.sum);
                            }
                          else
                            {
                              const double mean = infostatr.sum / (double) infostatr.nvals;
                              fprintf(stdout, "%#12.5g%#12.5g%#12.5g", infostatr.min, mean, infostatr.max);
                            }
                        }
                      else
                        {
                          fprintf(stdout, "                     nan            ");
                        }
                    }
                }
              else
                {
                  size_t nvals = 0;
                  if (Options::CDO_Memtype == MEMTYPE_FLOAT)
                    {
                      for (size_t i = 0; i < gridsize; i++)
                        {
                          if (!DBL_IS_EQUAL(arrayf[i * 2], missval) && !DBL_IS_EQUAL(arrayf[i * 2 + 1], missval))
                            {
                              infostatr.sum += arrayf[i * 2];
                              infostatr.sumi += arrayf[i * 2 + 1];
                              nvals++;
                            }
                        }
                    }
                  else
                    {
                      for (size_t i = 0; i < gridsize; i++)
                        {
                          if (!DBL_IS_EQUAL(array[i * 2], missval) && !DBL_IS_EQUAL(array[i * 2 + 1], missval))
                            {
                              infostatr.sum += array[i * 2];
                              infostatr.sumi += array[i * 2 + 1];
                              nvals++;
                            }
                        }
                    }

                  fpeRaised = 0;

                  imiss = gridsize - nvals;
                  infostatr.nvals += nvals;

                  if (loutput)
                    {
                      const double arrmean_r = (infostatr.nvals > 0) ? infostatr.sum / infostatr.nvals : 0;
                      const double arrmean_i = (infostatr.nvals > 0) ? infostatr.sumi / infostatr.nvals : 0;
                      fprintf(stdout, "   -  (%#12.5g,%#12.5g)  -", arrmean_r, arrmean_i);
                    }
                }

              if (loutput)
                {
                  reset_text_color(stdout);

                  fprintf(stdout, " : ");

                  // set_text_color(stdout, GREEN);
                  if (operfunc == E_NAME)
                    fprintf(stdout, "%-14s", varname);
                  else if (operfunc == E_CODE)
                    fprintf(stdout, "%4d   ", code);
                  else
                    fprintf(stdout, "%-14s", paramstr);
                  // reset_text_color(stdout);

                  if (Options::cdoVerbose)
                    {
                      char varextra[CDI_MAX_NAME];
                      vlistInqVarExtra(vlistID, varID, varextra);
                      fprintf(stdout, " : %s", varextra);
                    }

                  fprintf(stdout, "\n");
                }

              if (imiss != nmiss && nmiss) cdoPrint("Found %zu of %zu missing values!", imiss, nmiss);

              if (fpeRaised > 0) cdoWarning("floating-point exception reported: %s!", fpe_errstr(fpeRaised));

              if (operatorID == MAP)
                {
                  const auto nlon = gridInqXsize(gridID);
                  const auto nlat = gridInqYsize(gridID);

                  if (gridInqType(gridID) == GRID_GAUSSIAN || gridInqType(gridID) == GRID_LONLAT
                      || gridInqType(gridID) == GRID_CURVILINEAR
                      || (gridInqType(gridID) == GRID_GENERIC && nlon * nlat == gridInqSize(gridID) && nlon < 1024))
                    {
                      printMap(nlon, nlat, array.data(), missval, infostatr.min, infostatr.max);
                    }
                }
            }

          tsID++;
        }

      cdoStreamClose(streamID);
    }

  if (indg > 36 && operatorID != MAP)
    {
      set_text_color(stdout, BRIGHT);
      MpMO::Print("       :       Date     Time   %s Gridsize    Miss :     Minimum        Mean     Maximum : %s%s",
                  lvinfo ? "Nlevs" : "Level", e, v);
      reset_text_color(stdout);
    }

  cdoFinish();

  return nullptr;
}
