#ifndef CDO_CDIWRAPPER_H
#define CDO_CDIWRAPPER_H

// convert a CDI datatype to string
int datatype2str(int datatype, char *datatypestr);
int str2datatype(const char *datatypestr);

// create Taxis(cdi) with added check/setting of taxisType
int cdoTaxisCreate(int taxisType);

// cdi
extern "C" void cdiDefTableID(int tableID);
extern "C" void gridGenXvals(int xsize, double xfirst, double xlast, double xinc, double *xvals);
extern "C" void gridGenYvals(int gridtype, int ysize, double yfirst, double ylast, double yinc, double *yvals);

#endif
