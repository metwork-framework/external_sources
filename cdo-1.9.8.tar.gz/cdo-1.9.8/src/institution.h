
#ifndef CDO_INSTITUTION
#define CDO_INSTITUTION
void defineInstitution(const char *instarg);
#endif
