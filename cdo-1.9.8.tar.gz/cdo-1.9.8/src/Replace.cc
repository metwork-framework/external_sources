/*
  This file is part of CDO. CDO is a collection of Operators to
  manipulate and analyse Climate model Data.

  Copyright (C) 2003-2019 Uwe Schulzweida, <uwe.schulzweida AT mpimet.mpg.de>
  See COPYING file for copying and redistribution conditions.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
*/

/*
   This module contains the following operators:

      Replace    replace         Replace variables
*/

#include <cdi.h>

#include "cdo_options.h"
#include "process_int.h"
#include "cdo_vlist.h"
#include "cdo_zaxis.h"

#define MAX_VARS 1024

void *
Replace(void *process)
{
  int varID, varID1, varID2;
  int nrecs = 0;
  int levelID, levelID2;
  int nrecs2;
  int nchvars = 0;
  int idx;
  char varname1[CDI_MAX_NAME], varname2[CDI_MAX_NAME];
  size_t nmiss = 0;
  int varlist1[MAX_VARS], varlist2[MAX_VARS];
  std::vector<std::vector<int>> varlevel;
  std::vector<std::vector<size_t>> varnmiss2;
  Varray2D<double> vardata2;

  cdoInitialize(process);

  const auto streamID1 = cdoOpenRead(0);

  const auto vlistID1 = cdoStreamInqVlist(streamID1);
  const auto taxisID1 = vlistInqTaxis(vlistID1);
  const auto taxisID3 = taxisDuplicate(taxisID1);

  const auto streamID2 = cdoOpenRead(1);

  const auto vlistID2 = cdoStreamInqVlist(streamID2);

  VarList varList1, varList2;
  varListInit(varList1, vlistID1);
  varListInit(varList2, vlistID2);

  // compare all variables in vlistID2

  const auto nvars1 = vlistNvars(vlistID1);
  const auto nvars2 = vlistNvars(vlistID2);

  for (varID2 = 0; varID2 < nvars2; varID2++)
    {
      vlistInqVarName(vlistID2, varID2, varname2);

      for (varID1 = 0; varID1 < nvars1; varID1++)
        {
          vlistInqVarName(vlistID1, varID1, varname1);
          if (strcmp(varname1, varname2) == 0) break;
        }

      if (varID1 < nvars1)
        {
          const auto gridsize1 = varList1[varID1].gridsize;
          const auto nlevel1 = varList1[varID1].nlevels;

          const auto gridsize2 = varList2[varID2].gridsize;
          const auto nlevel2 = varList2[varID2].nlevels;

          if (gridsize1 != gridsize2) cdoAbort("Variables have different gridsize!");

          if (nlevel1 < nlevel2) cdoAbort("Variables have different number of levels!");

          if (Options::cdoVerbose) cdoPrint("Variable %s replaced.", varname1);

          varlist1[nchvars] = varID1;
          varlist2[nchvars] = varID2;
          nchvars++;
          if (nchvars > MAX_VARS) cdoAbort("Internal problem - too many variables!");
        }
      else
        {
          cdoPrint("Variable %s not found!", varname2);
        }
    }

  if (nchvars)
    {
      vardata2.resize(nchvars);
      varnmiss2.resize(nchvars);
      varlevel.resize(nchvars);
      for (idx = 0; idx < nchvars; idx++)
        {
          varID1 = varlist1[idx];
          varID2 = varlist2[idx];
          const auto nlevel1 = varList1[varID1].nlevels;
          const auto nlevel2 = varList2[varID2].nlevels;
          const auto gridsize = varList2[varID2].gridsize;
          vardata2[idx].resize(nlevel2 * gridsize);
          varnmiss2[idx].resize(nlevel2);
          varlevel[idx].resize(nlevel1);
          /*
          for ( levelID = 0; levelID < nlevel1; levelID++ )
            varlevel[idx][levelID] = levelID;
          */
          if (nlevel2 <= nlevel1)
            {
              Varray<double> level1(nlevel1);
              Varray<double> level2(nlevel2);
              cdoZaxisInqLevels(vlistInqVarZaxis(vlistID1, varID1), level1.data());
              cdoZaxisInqLevels(vlistInqVarZaxis(vlistID2, varID2), level2.data());

              for (levelID = 0; levelID < nlevel1; levelID++) varlevel[idx][levelID] = -1;

              for (int l2 = 0; l2 < nlevel2; l2++)
                {
                  int l1;
                  for (l1 = 0; l1 < nlevel1; l1++)
                    if (IS_EQUAL(level2[l2], level1[l1]))
                      {
                        varlevel[idx][l1] = l2;
                        break;
                      }

                  if (l1 == nlevel1) cdoWarning("Level %g not found!", level2[l2]);
                }
            }
        }
    }

  const auto vlistID3 = vlistDuplicate(vlistID1);

  const auto streamID3 = cdoOpenWrite(2);

  vlistDefTaxis(vlistID3, taxisID3);
  cdoDefVlist(streamID3, vlistID3);

  auto gridsize = vlistGridsizeMax(vlistID1);
  Varray<double> array(gridsize);

  const int nts2 = vlistNtsteps(vlistID2);

  int tsID = 0;
  while ((nrecs = cdoStreamInqTimestep(streamID1, tsID)))
    {
      taxisCopyTimestep(taxisID3, taxisID1);

      if (tsID == 0 || (nts2 != 0 && nts2 != 1))
        {
          nrecs2 = cdoStreamInqTimestep(streamID2, tsID);
          if (nrecs2 == 0) cdoAbort("Input streams have different number of timesteps!");

          for (int recID = 0; recID < nrecs2; recID++)
            {
              cdoInqRecord(streamID2, &varID, &levelID);

              for (idx = 0; idx < nchvars; idx++)
                if (varlist2[idx] == varID)
                  {
                    const size_t offset = varList2[varID].gridsize * levelID;
                    cdoReadRecord(streamID2, &vardata2[idx][offset], &nmiss);
                    varnmiss2[idx][levelID] = nmiss;
                    break;
                  }
            }
        }

      cdoDefTimestep(streamID3, tsID);

      for (int recID = 0; recID < nrecs; recID++)
        {
          cdoInqRecord(streamID1, &varID, &levelID);

          double *parray = array.data();

          for (idx = 0; idx < nchvars; idx++)
            if (varlist1[idx] == varID)
              {
                levelID2 = varlevel[idx][levelID];
                if (levelID2 != -1)
                  {
                    const auto offset = varList1[varID].gridsize * levelID2;
                    parray = &vardata2[idx][offset];
                    nmiss = varnmiss2[idx][levelID2];
                    break;
                  }
              }

          if (idx == nchvars) cdoReadRecord(streamID1, parray, &nmiss);

          cdoDefRecord(streamID3, varID, levelID);
          cdoWriteRecord(streamID3, parray, nmiss);
        }

      tsID++;
    }

  cdoStreamClose(streamID3);
  cdoStreamClose(streamID2);
  cdoStreamClose(streamID1);

  cdoFinish();

  return 0;
}
