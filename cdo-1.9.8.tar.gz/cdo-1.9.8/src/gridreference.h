#ifndef REFERENCE_TO_GRID_H
#define REFERENCE_TO_GRID_H

int referenceToGrid(int gridID1);

#endif
