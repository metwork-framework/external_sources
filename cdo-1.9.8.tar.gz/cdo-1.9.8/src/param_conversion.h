#ifndef PARAM_CONVERSION_H
#define PARAM_CONVERSION_H

#include <string>

const char *parameter2word(const char *cstring);
double parameter2double(const char *cstring);
int parameter2int(const char *cstring);
long parameter2long(const char *cstring);
size_t parameter2sizet(const char *cstring);
int parameter2intlist(const char *cstring);

const std::string &parameter2word(const std::string &string);
double parameter2double(const std::string &string);
bool parameter2bool(const std::string &string);
int parameter2int(const std::string &string);
long parameter2long(const std::string &string);
size_t parameter2sizet(const std::string &string);
int parameter2intlist(const std::string &string);

double radius_str_to_deg(const char *string);
int
stringToParam(std::string paramstr);

int
stringToParam(const char * paramstr);

#endif
