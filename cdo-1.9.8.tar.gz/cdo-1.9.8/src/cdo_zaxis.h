#ifndef CDO_ZAXIS_H
#define CDO_ZAXIS_H

#include <string>

int cdoDefineZaxis(const char *zaxisfile);
int cdoDefineZaxis(const std::string &p_zaxisfile);
void defineZaxis(const char *zaxisarg);
int zaxisFromName(const char *zaxisname);
int zaxis2ltype(int zaxisID);
double cdoZaxisInqLevel(int zaxisID, int levelID);
int cdoZaxisInqLevels(int zaxisID, double *levels);

#endif
