#ifndef CDO_FEATURES_H
#define CDO_FEATURES_H

void cdoConfig(const std::string &option);
void printFeatures(void);
void printLibraries(void);

#endif
