-- cleanup
DELETE FROM spatial_ref_sys;
