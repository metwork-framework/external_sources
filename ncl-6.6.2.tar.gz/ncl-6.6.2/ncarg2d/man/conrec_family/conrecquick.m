.TH Conrecquick 3NCARG "March 1993" UNIX "NCAR GRAPHICS"
.na
.nh
.SH NAME
Conrecquick - This utility has been merged into the Conrec_family.
Type "man conrec_family" to see its man page.
