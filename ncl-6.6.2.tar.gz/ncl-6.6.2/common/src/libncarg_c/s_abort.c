/*
 *	$Id: s_abort.c,v 1.4 2008-07-27 12:23:45 haley Exp $
 */
/************************************************************************
*                                                                       *
*			     Copyright (C)  2000	                        		*
*	     University Corporation for Atmospheric Research		        *
*			     All Rights Reserved			                        *
*                                                                       *
*    The use of this Software is governed by a License Agreement.       *
*                                                                       *
************************************************************************/

/*
 * This routine is missing from certain versions of DECRISC systems.
 */

void s_abort()
{}
